import { PrismaClient } from '@prisma/client'

/*
 * Seed script for the STEB.IO database.
 *
 * This will create 12 users/creators and 24 products across several
 * categories. Images are pulled from `picsum.photos` and are for demo
 * purposes only. Each product receives an initial release.
 */
const prisma = new PrismaClient()

const categories = [
  'AI',
  'Education',
  'Sports Picks',
  'Trading',
  'Design',
  'Coding',
  'Templates',
  'Communities',
]

const sampleImg = (i: number) => `https://picsum.photos/seed/steb-${i}/1200/800`

async function main() {
  // Create 12 users and associated creators
  const creators: any[] = []
  for (let i = 1; i <= 12; i++) {
    const user = await prisma.user.create({
      data: {
        email: `creator${i}@steb.io`,
        name: `Creator ${i}`,
      },
    })
    const creator = await prisma.creator.create({
      data: {
        userId: user.id,
        displayName: `Creator ${i}`,
        bio: 'Building premium digital products on STEB.',
        avatarUrl: sampleImg(i),
        bannerUrl: sampleImg(i + 100),
      },
    })
    creators.push(creator)
  }
  // Create 24 products
  for (let i = 1; i <= 24; i++) {
    const creator = creators[(i - 1) % creators.length]
    const product = await prisma.product.create({
      data: {
        slug: `product-${i}`,
        title: `Premium Product ${i}`,
        description:
          'High‑quality digital product for creators and power users.',
        category: categories[(i - 1) % categories.length],
        priceCents: 2900 + ((i % 5) * 1000),
        images: [sampleImg(i), sampleImg(i + 50)],
        creatorId: creator.id,
        rating: 4 + (i % 2 ? 0.5 : 0),
        ratingCount: 10 + i,
      },
    })
    await prisma.release.create({
      data: {
        productId: product.id,
        version: '1.0.0',
        notes: 'Initial release',
      },
    })
  }
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
