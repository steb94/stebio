# @stebio/ui

This package is intended to house a reusable design system for STEB.IO. You
can extract buttons, cards, badges, rating stars, skeleton loaders, dialogs,
tabs, and other UI primitives here to ensure a consistent look and feel
across the Next.js application.

Currently this is a placeholder package. You can start by exporting simple
components from `packages/ui/src` and referencing them in the app.