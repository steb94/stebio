# @stebio/core

This package provides shared logic and types across the STEB.IO monorepo.
It can include TypeScript type definitions, validation schemas using `zod`,
common utilities, and API client helpers. By centralising these pieces,
both the web app and worker can import them without duplication.

The package is currently empty and serves as a placeholder for future
development.