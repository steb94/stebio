/**
 * Home page for STEB.IO.
 *
 * This simple component renders a hero section encouraging users to explore
 * the marketplace. In a full implementation you would fetch sections
 * (trending products, top creators, etc.) from your API and display
 * components from your design system.
 */
export default function HomePage() {
  return (
    <main className="px-6 py-10 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold">Discover premium digital products & memberships</h1>
      <p className="opacity-80 mt-2">
        Browse freely, search products and creators, and purchase with confidence.
      </p>
      {/* TODO: Add search input, category rail, and sections for trending products */}
    </main>
  )
}
