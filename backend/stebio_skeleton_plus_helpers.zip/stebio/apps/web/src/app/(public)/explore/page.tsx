/**
 * Explore page showing a grid of products with basic filter options.
 */
export default async function ExplorePage() {
  // Fetch the first page of products. In a real implementation you would
  // handle query parameters (category, search, sorting) and pagination.
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_BASE || ''}/api/products?take=24`,
    { cache: 'no-store' }
  )
  if (!res.ok) {
    return <div className="p-10">Failed to load products.</div>
  }
  const data = await res.json()
  return (
    <main className="px-6 py-10 max-w-6xl mx-auto">
      <h1 className="text-2xl font-semibold mb-6">Explore</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {data.items?.map((p: any) => (
          <a
            key={p.slug}
            href={`/product/${p.slug}`}
            className="block border border-white/10 rounded-xl p-4 hover:border-white/30"
          >
            <img
              src={p.images?.[0]}
              alt="Product image"
              className="rounded-lg mb-3 object-cover w-full h-40"
            />
            <div className="font-medium mb-1">{p.title}</div>
            <div className="opacity-70 text-sm">
              ${'{'}(p.priceCents / 100).toFixed(2){'}'}
            </div>
          </a>
        ))}
      </div>
    </main>
  )
}
