/**
 * Individual product page.
 *
 * Displays images, title, description and a placeholder for checkout.
 */
export default async function ProductPage({ params }: { params: { slug: string } }) {
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_BASE || ''}/api/products/${params.slug}`,
    { cache: 'no-store' }
  )
  if (!res.ok) {
    return <div className="p-10">Product not found.</div>
  }
  const p = await res.json()
  return (
    <main className="px-6 py-10 max-w-4xl mx-auto">
      <img
        src={p.images?.[0]}
        alt="Product image"
        className="rounded-xl mb-6 object-cover w-full h-60"
      />
      <h1 className="text-3xl font-bold mb-2">{p.title}</h1>
      <p className="opacity-80 mb-4">{p.description}</p>
      {/* Placeholder for tabs: Overview, What's included, Changelog, etc. */}
      <form
        action="/api/checkout"
        method="post"
        className="mt-6 p-4 border border-white/10 rounded-lg bg-black/20"
      >
        {/* In a real app, you would create the checkout session via a client action */}
        <input type="hidden" name="slug" value={p.slug} />
        <button
          type="submit"
          className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"
        >
          Buy now for ${'{'}(p.priceCents / 100).toFixed(2){'}'}
        </button>
      </form>
    </main>
  )
}
