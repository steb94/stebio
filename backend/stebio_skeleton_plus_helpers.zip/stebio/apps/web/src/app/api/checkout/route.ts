import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '../../../lib/db'
import { stripe } from '../../../lib/stripe'
import { env } from '../../../lib/env'

/**
 * POST /api/checkout
 *
 * Creates a Stripe checkout session for a given product slug. The request
 * body should contain a JSON object with the `slug` of the product and
 * optionally a `coupon` code. On success, returns the session id and
 * hosted URL.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null)
  if (!body || typeof body.slug !== 'string') {
    return NextResponse.json({ error: 'Invalid payload' }, { status: 400 })
  }
  const { slug, coupon } = body
  const product = await prisma.product.findUnique({ where: { slug } })
  if (!product) {
    return NextResponse.json({ error: 'Product not found' }, { status: 404 })
  }
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [
      {
        price_data: {
          currency: 'usd',
          unit_amount: product.priceCents,
          product_data: { name: product.title },
        },
        quantity: 1,
      },
    ],
    discounts: coupon ? [{ coupon }] : undefined,
    success_url: `${env.NEXT_PUBLIC_SITE_URL}/account?success=1`,
    cancel_url: `${env.NEXT_PUBLIC_SITE_URL}/product/${slug}?canceled=1`,
    metadata: { slug },
  })
  return NextResponse.json({ id: session.id, url: session.url })
}
