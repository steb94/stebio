import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '../../../lib/db'

/**
 * GET /api/products
 *
 * Returns a paginated list of active products. Supports optional query
 * parameters:
 * - `take` (number) - max results to return, capped at 48
 * - `page` (number) - page number (1-based)
 * - `category` (string) - filter by product category
 * - `q` (string) - search string
 * - `order` (string) - sorting: 'newest', 'price_asc', 'price_desc', default is by rating
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const take = Math.min(parseInt(searchParams.get('take') || '24', 10), 48)
  const page = Math.max(parseInt(searchParams.get('page') || '1', 10), 1)
  const skip = (page - 1) * take
  const category = searchParams.get('category') || undefined
  const q = searchParams.get('q') || undefined
  const order = searchParams.get('order') || 'rating'

  const where: any = { active: true }
  if (category) where.category = category
  if (q) {
    where.OR = [
      { title: { contains: q, mode: 'insensitive' as const } },
      { description: { contains: q, mode: 'insensitive' as const } },
    ]
  }

  let orderBy: any = { rating: 'desc' }
  if (order === 'newest') orderBy = { createdAt: 'desc' }
  else if (order === 'price_asc') orderBy = { priceCents: 'asc' }
  else if (order === 'price_desc') orderBy = { priceCents: 'desc' }

  const [items, total] = await Promise.all([
    prisma.product.findMany({
      where,
      orderBy,
      skip,
      take,
      select: {
        slug: true,
        title: true,
        priceCents: true,
        rating: true,
        ratingCount: true,
        images: true,
        category: true,
        creator: { select: { displayName: true } },
      },
    }),
    prisma.product.count({ where }),
  ])
  return NextResponse.json({ items, page, take, total })
}
