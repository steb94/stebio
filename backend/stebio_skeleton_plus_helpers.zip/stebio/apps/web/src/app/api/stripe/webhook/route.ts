import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '../../../lib/stripe'
import { env } from '../../../lib/env'
import { prisma } from '../../../lib/db'

/**
 * POST /api/stripe/webhook
 *
 * Handles Stripe webhook events for checkout completion, refunds and disputes.
 * On checkout completion, creates an order and entitlement for the user.
 */
export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature')
  if (!sig) {
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 })
  }
  const rawBody = await req.text()
  let event
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, env.STRIPE_WEBHOOK_SECRET)
  } catch (err: any) {
    return new NextResponse(`Webhook Error: ${err.message}`, { status: 400 })
  }
  switch (event.type) {
    case 'checkout.session.completed': {
      const cs = event.data.object as any
      const slug = cs.metadata?.slug
      const email = cs.customer_details?.email
      if (!slug || !email) break
      const product = await prisma.product.findUnique({ where: { slug } })
      if (!product) break
      const user = await prisma.user.upsert({
        where: { email },
        update: {},
        create: { email },
      })
      await prisma.order.create({
        data: {
          userId: user.id,
          productId: product.id,
          amountCents: cs.amount_total || product.priceCents,
          status: 'PAID',
          stripeSessionId: cs.id,
        },
      })
      await prisma.entitlement.create({ data: { userId: user.id, productId: product.id } })
      break
    }
    case 'charge.refunded': {
      // TODO: revoke entitlement on refund
      break
    }
    case 'dispute.created': {
      // TODO: flag order or disable entitlement
      break
    }
    default:
      break
  }
  return NextResponse.json({ received: true })
}

// Disable the default body parser to receive raw body
export const config = { api: { bodyParser: false } } as any
