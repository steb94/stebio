import Stripe from 'stripe'
import { env } from './env'

/**
 * Initialize a Stripe client using the secret key from the environment.
 */
export const stripe = new Stripe(env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
})
