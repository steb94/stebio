/**
 * NextAuth configuration outline.
 *
 * This file provides a basic setup for NextAuth using the Prisma adapter.
 * To enable authentication providers, fill in the provider options with
 * credentials from your OAuth providers (Google, Discord, etc.).
 */
import { PrismaAdapter } from '@next-auth/prisma-adapter'
import GoogleProvider from 'next-auth/providers/google'
import DiscordProvider from 'next-auth/providers/discord'
import CredentialsProvider from 'next-auth/providers/credentials'
import NextAuth from 'next-auth'
import { prisma } from './db'

export const authOptions = {
  adapter: PrismaAdapter(prisma),
  session: { strategy: 'jwt' as const },
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
    }),
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID || '',
      clientSecret: process.env.DISCORD_CLIENT_SECRET || '',
    }),
    CredentialsProvider({
      name: 'Email',
      credentials: { email: { label: 'Email', type: 'text' } },
      async authorize(credentials) {
        // Allow passwordless login using email only. In a real implementation
        // you should verify the user via magic link or token.
        if (!credentials?.email) return null
        return { id: credentials.email, email: credentials.email }
      },
    }),
  ],
}

// Export the NextAuth handler. In the App Router, you can re-export
// handlers at `/api/auth/[...nextauth]/route.ts` like so:
//   export { GET, POST } from '@/src/lib/auth'
const handler = NextAuth(authOptions)
export const { handlers, auth, signIn, signOut } = handler as any
