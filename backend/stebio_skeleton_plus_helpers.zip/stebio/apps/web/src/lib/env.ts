import { z } from 'zod'

/**
 * A typed and validated environment loader.
 *
 * This uses `zod` to ensure required environment variables are present
 * and correctly formatted. If variables are missing or invalid, an
 * exception will be thrown at import time.
 */
const EnvSchema = z.object({
  NODE_ENV: z.string().default('production'),
  NEXT_PUBLIC_SITE_URL: z.string().url(),
  NEXT_PUBLIC_API_BASE: z.string().url().optional(),
  NEXTAUTH_URL: z.string().url(),
  NEXTAUTH_SECRET: z.string(),
  DATABASE_URL: z.string(),
  STRIPE_SECRET_KEY: z.string(),
  STRIPE_WEBHOOK_SECRET: z.string(),
  STRIPE_CONNECT_CLIENT_ID: z.string(),
  FILE_STORAGE: z.enum(['s3']).default('s3'),
  S3_BUCKET: z.string(),
  S3_REGION: z.string(),
  S3_ACCESS_KEY_ID: z.string(),
  S3_SECRET_ACCESS_KEY: z.string(),
})

export const env = EnvSchema.parse(process.env)
