import { PrismaClient } from '@prisma/client'

/**
 * Shared Prisma client for the Next.js app.
 *
 * In development we attach the client to the global object to prevent
 * exhausting database connections due to hot reloading. In production a
 * single instance is created per invocation.
 */
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient }

export const prisma: PrismaClient =
  globalForPrisma.prisma ?? new PrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma
