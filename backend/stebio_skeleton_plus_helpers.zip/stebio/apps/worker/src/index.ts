/**
 * Worker entry point.
 *
 * In a production setup, this worker could handle background tasks such
 * as Stripe webhook events, sending transactional emails, or queue
 * processing. For now it simply exports a handler stub.
 */
export function handler(event: any) {
  console.log('Worker received event:', event)
  // TODO: implement background job processing
}
